import os

def print_green(text):
    """Prints text in green color"""
    print(f"\033[92m{text}\033[0m")

def clear_screen():
    """Clears the console screen"""
    os.system('cls' if os.name == 'nt' else 'clear')

def display_menu():
    """Displays the main menu"""
    print("\n" + "="*50)
    print("MAIN MENU")
    print("="*50)
    print("1) Create exe")
    print("2) Create FUD exe") 
    print("3) Read rules")
    print("4) Exit")
    print("="*50)

def main():
    while True:
        clear_screen()
        
        # Print welcome message in green color
        print_green("Welcome to Crypto grabber.")
        print()
        
        # Display menu
        display_menu()
        
        # Get user choice
        choice = input("\nSelect menu item (1-4): ").strip()
        
        # Process choice
        if choice in ['1', '2', '3']:
            clear_screen()
            print("\n" + "="*50)
            print("INFORMATION")
            print("="*50)
            print("about buy - write to @cybersystem512 Telegram account.")
            print("thank you")
            print("="*50)
            input("\nPress Enter to return to menu...")
        
        elif choice == '4':
            print("\nExiting program...")
            break
        
        else:
            print("\nInvalid choice! Please select item from 1 to 4.")
            input("Press Enter to continue...")

if __name__ == "__main__":
    main()